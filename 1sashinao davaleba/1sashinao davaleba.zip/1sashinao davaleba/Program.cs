﻿// See https://aka.ms/new-console-template for more information


////priveli savarjisho

///davaleba 1
Console.WriteLine("daamate sheni tel number :");
string telnomeri = Console.ReadLine();


double nomeri = Convert.ToDouble(telnomeri);
Console.WriteLine($"sheni nomeria {telnomeri}");

///davaleba 1 (end)



///davaleba 2 

Console.Write("chawere sheni meore nomeri :");
string telnomeri2 = Console.ReadLine(); 
double nomeri2  = Convert.ToDouble(telnomeri2);
Console.WriteLine($"sheni meore nomeria : {nomeri2}");



///davaleba 2 (end)



///davaleba 3

double number1 = 5.0;
double number2 = 3.0;
double shedegi = number1 * number2;
Console.WriteLine($"{number1} + {number2} = {shedegi}");


///davaleba 3 (end)






////priveli savarjisho  (end)






///meore savarjisho 

///davaleba 1
Console.WriteLine("sheiyvane sheni asaki :");
string input = Console.ReadLine();  
int nNumber1= Convert.ToInt32(input);
Console.WriteLine($"sheni asakia : {nNumber1}");

///davaleba 1 (end)




///davaleba 2 


Console.WriteLine("chawere sheni meore asaki : ");
string input2 = Console.ReadLine(); 
int nNumber2= Convert.ToInt32(input2);
Console.WriteLine($"sheni moere asakia {nNumber2}");



///davaleba 2  (end)
///



////davaleba 3 

int NUMBER1 = 40;
int NUMBER2 = 60;


int RESULT = NUMBER1 * NUMBER2;
Console.WriteLine($"{NUMBER1} movumatot {NUMBER2} aris {RESULT}");



////davaleba 3 (end)



///davaleba 4 

int lewishamilton = 7;
bool maxversttapen = lewishamilton > 3;
Console.WriteLine($"{lewishamilton}> {maxversttapen} ");

///davaleba 4 (end)



/// meore savarjisho  (end)




///mesame savarjisho 


///davaleba 1 


Console.WriteLine("Chawere sheni pozicia gridze :");
string position = Console.WriteLine();
double resuLLT = Convert.ToDouble(position);
Console.WriteLine($"sheni poziciaa : {resuLLT}");



////davaleba 1 (end)








/// davbaleba 2 

Console.WriteLine("SAY YOUR MOST GOAT F1 DRIVER NUMBER :");
string f1input = Console.ReadLine();    
double resultforf1fans = Convert.ToDouble(f1input);
Console.WriteLine($"goat hamilton : {resultforf1fans}");


/// davaleba 2 (end)







/// dabaleba 3 

double ricxvi1 = 100;
double ricxvi2 = 200;
double sum = ricxvi1 + ricxvi2;
Console.WriteLine($"{ricxvi1}+{ricxvi2}={sum}");

///davaleba 3 (end)



///dabaleba 4 

double sum1 = 10.0;
bool ricXXvi = sum1 %2 == 0;


Console.WriteLine($"aris sum1 ({sum1}) even ? {ricXXvi} ");


///davaleba 4 (end)




///mesame savarjisho (end)
